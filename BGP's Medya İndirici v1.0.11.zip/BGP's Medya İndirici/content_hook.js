// content_hook.js — SAYFANIN İÇİNDE (MAIN world), oynatıcıdan önce çalışır.
// Oynatıcının video/ses SourceBuffer'larına verdiği ham baytları yakalar.
//
// Fikir: YouTube HD'yi tek dosya olarak vermez; çözülmüş parçaları MediaSource'a
// besler. Her kanala eklenen baytları sırayla birleştirirsek o kanalın orijinal
// dosyası çıkar (başı "init" parçası ile başlamak şartıyla). Bunun için videoyu
// sürekli ileri sararak oynatıcıyı tamponu doldurmaya zorlarız.
(function () {
  'use strict';
  if (window.__ytdlHook) return;
  window.__ytdlHook = true;

  const NS = 'ytdl';
  const S = {
    capturing: false, busy: false, cancel: false,
    tracks: Object.create(null),    // 'video' | 'audio' -> { mime, parts, init, broken }
    lastInit: Object.create(null),  // her kanalın son init parçası (yakalama kapalıyken de saklanır)
    sb: Object.create(null)         // her kanalın canlı SourceBuffer'ı
  };
  const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

  const isShorts = () => /^\/shorts\//.test(location.pathname);
  const vidId = () => {
    try {
      if (isShorts()) { const m = location.pathname.match(/^\/shorts\/([^/?#]+)/); return m ? m[1] : null; }
      return new URLSearchParams(location.search).get('v');
    } catch (e) { return null; }
  };
  const player = () => (isShorts()
    ? (document.getElementById('shorts-player') || document.getElementById('movie_player'))
    : document.getElementById('movie_player'));
  const video = () => (isShorts()
    ? (document.querySelector('ytd-reel-video-renderer[is-active] video') ||
       document.querySelector('#shorts-player video') || document.querySelector('video'))
    : (document.querySelector('#movie_player video') || document.querySelector('video')));
  const isAd = () => { const p = player(); return !!(p && p.classList && p.classList.contains('ad-showing')); };

  // ---- Codec filtresi: oynatıcıyı H.264 + AAC (MP4) akışına zorla -----------
  // YouTube normalde VP9/AV1 + Opus (WebM) seçer; bunlar Windows Filmler ve TV, TV'ler,
  // eski telefonlar gibi yerlerde açılmaz. Bu türleri "desteklenmiyor" gösterirsek
  // oynatıcı avc1 (H.264) + mp4a (AAC) akışlarına düşer: her yerde çalışır ve
  // dönüştürmeden kopyalanabilir. Not: 1440p/4K sadece VP9/AV1 olduğundan
  // oynatıcıda en fazla 1080p görünür. Kapatmak için FORCE_H264 = false yap.
  const FORCE_H264 = true;
  const BLOCKED = /av01|av1\b|vp0?9|vp8|opus|vorbis|webm/i;
  const blocked = (t) => FORCE_H264 ? (typeof t === 'string' && BLOCKED.test(t))
                                    : (typeof t === 'string' && /av01|av1\b/i.test(t));
  try {
    const o = MediaSource.isTypeSupported.bind(MediaSource);
    MediaSource.isTypeSupported = (t) => (blocked(t) ? false : o(t));
  } catch (e) {}
  try {
    const o = HTMLMediaElement.prototype.canPlayType;
    HTMLMediaElement.prototype.canPlayType = function (t) { return blocked(t) ? '' : o.call(this, t); };
  } catch (e) {}
  try {
    const mc = navigator.mediaCapabilities;
    if (mc && mc.decodingInfo) {
      const o = mc.decodingInfo.bind(mc);
      mc.decodingInfo = (cfg) => {
        const v = cfg && cfg.video && cfg.video.contentType;
        const a = cfg && cfg.audio && cfg.audio.contentType;
        return (blocked(v) || blocked(a))
          ? Promise.resolve({ supported: false, smooth: false, powerEfficient: false })
          : o(cfg);
      };
    }
  } catch (e) {}

  // ---- MSE yakalama ---------------------------------------------------------
  const toU8 = (d) => {
    if (d instanceof Uint8Array) return d;
    if (d instanceof ArrayBuffer) return new Uint8Array(d);
    if (ArrayBuffer.isView(d)) return new Uint8Array(d.buffer, d.byteOffset, d.byteLength);
    return null;
  };
  // WebM: EBML sihirli sayısı. MP4: 'ftyp' kutusu.
  const isInit = (u) =>
    (u.length >= 4 && u[0] === 0x1A && u[1] === 0x45 && u[2] === 0xDF && u[3] === 0xA3) ||
    (u.length >= 8 && u[4] === 0x66 && u[5] === 0x74 && u[6] === 0x79 && u[7] === 0x70);
  const same = (a, b) => {
    if (a.length !== b.length) return false;
    for (let i = 0; i < a.length; i++) if (a[i] !== b[i]) return false;
    return true;
  };

  const origAdd = MediaSource.prototype.addSourceBuffer;
  MediaSource.prototype.addSourceBuffer = function (mime) {
    const sb = origAdd.call(this, mime);
    try {
      sb.__ytdlMime = mime;
      sb.__ytdlKind = /audio/i.test(mime) ? 'audio' : /video/i.test(mime) ? 'video' : null;
      if (sb.__ytdlKind) S.sb[sb.__ytdlKind] = sb;
    } catch (e) {}
    return sb;
  };

  function record(kind, u, init, mime) {
    let t = S.tracks[kind];
    if (!t) {
      if (init) {
        S.tracks[kind] = { mime, parts: [u.slice()], init: u.slice(), broken: false };
      } else if (S.lastInit[kind]) {
        // init yakalamadan önce geldi: saklanan son init ile başlat
        const li = S.lastInit[kind];
        S.tracks[kind] = { mime: li.mime, parts: [li.bytes, u.slice()], init: li.bytes, broken: false };
      }
      return;
    }
    if (init) {
      if (same(t.init, u)) return;   // aynı init tekrar geldi: dosyaya ekleme
      t.broken = true;               // farklı init = kalite/format değişti
      return;
    }
    t.parts.push(u.slice());
  }

  const origAppend = SourceBuffer.prototype.appendBuffer;
  SourceBuffer.prototype.appendBuffer = function (data) {
    try {
      const kind = this.__ytdlKind;
      if (kind) {
        const u = toU8(data);
        if (u && u.length) {
          const init = isInit(u);
          if (init) S.lastInit[kind] = { bytes: u.slice(), mime: this.__ytdlMime || '' };
          if (S.capturing) record(kind, u, init, this.__ytdlMime || '');
        }
      }
    } catch (e) { /* oynatmayı asla bozma */ }
    return origAppend.apply(this, arguments);
  };

  function assemble(kind) {
    const t = S.tracks[kind];
    if (!t || !t.parts.length) return null;
    let n = 0;
    for (const p of t.parts) n += p.length;
    const out = new Uint8Array(n);
    let o = 0;
    for (const p of t.parts) { out.set(p, o); o += p.length; }
    return { bytes: out, mime: t.mime, broken: t.broken };
  }

  // ---- oynatıcı yardımcıları -----------------------------------------------
  const LEVEL = { 2160: 'hd2160', 1440: 'hd1440', 1080: 'hd1080', 720: 'hd720', 480: 'large', 360: 'medium', 240: 'small', 144: 'tiny' };
  const HEIGHT = {};
  for (const h in LEVEL) HEIGHT[LEVEL[h]] = Number(h);

  function setQuality(level) {
    const p = player();
    if (!p) return;
    try { p.setPlaybackQualityRange && p.setPlaybackQualityRange(level, level); } catch (e) {}
    try { p.setPlaybackQuality && p.setPlaybackQuality(level); } catch (e) {}
  }
  const currentQuality = () => { try { const q = player().getPlaybackQuality(); return HEIGHT[q] ? q : null; } catch (e) { return null; } };
  const availableHeights = () => {
    try { return (player().getAvailableQualityLevels() || []).map((l) => HEIGHT[l]).filter(Boolean); } catch (e) { return []; }
  };
  // Oynatıcı API'si ile sar: YouTube'un kendi akış konumunu da günceller.
  function seekVia(sec) {
    const p = player();
    try { if (p && p.seekTo) { p.seekTo(sec, true); return; } } catch (e) {}
    try { video().currentTime = sec; } catch (e) {}
  }

  function coveredTo(kinds, from) {
    let out = null;
    for (const k of kinds) {
      const sb = S.sb[k];
      if (!sb) return null;
      let e = null;
      try {
        const b = sb.buffered;
        for (let i = 0; i < b.length; i++) {
          if (b.start(i) <= from + 0.6 && b.end(i) >= from) { e = b.end(i); break; }
        }
      } catch (err) { return null; }
      if (e == null) return null;
      out = out == null ? e : Math.min(out, e);
    }
    return out;
  }
  function bufferedStartOf(kind, t) {
    const sb = S.sb[kind];
    if (!sb) return null;
    try {
      const b = sb.buffered;
      for (let i = 0; i < b.length; i++) if (b.start(i) <= t + 0.5 && b.end(i) >= t) return b.start(i);
    } catch (e) {}
    return null;
  }

  // ---- yakalama döngüsü -----------------------------------------------------
  async function capture(o, onProgress) {
    const v = video(), p = player();
    if (!v || !p) throw new Error('Oynatıcı bulunamadı.');
    const dur = v.duration;
    if (!isFinite(dur) || dur <= 0) throw new Error('Video süresi okunamadı (canlı yayınlar desteklenmez).');
    if (isAd()) throw new Error('Şu an reklam oynuyor. Reklam bitince tekrar dene (reklam engelleyici kullan).');

    const needVideo = o.needVideo !== false;
    const kinds = needVideo ? ['video', 'audio'] : ['audio'];
    const end = Math.min(o.end > 0 ? o.end : dur, dur);
    const start = Math.max(0, Math.min(o.start || 0, Math.max(0, end - 1)));
    const id = vidId();
    const prev = { paused: v.paused, time: v.currentTime, muted: v.muted, q: currentQuality() };
    const targetQ = o.quality;
    const preQ = targetQ === 'tiny' || targetQ === 'small' ? 'medium' : 'small';

    S.cancel = false;
    try { v.muted = true; v.pause(); } catch (e) {}

    // 1) düşük kalite + uzak bir noktaya git: sonraki sıçrama iki kanalı da yeniden yükletir
    setQuality(preQ);
    await sleep(500);
    seekVia(start > 10 ? 0 : Math.min(35, Math.max(1, dur - 5)));
    await sleep(700);

    // 2) kaydı aç, hedef kaliteye geç, başlangıca sıçra
    S.tracks = Object.create(null);
    S.capturing = true;
    setQuality(targetQ);
    seekVia(start);
    await sleep(500);

    const haveInits = () => S.tracks.audio && (!needVideo || S.tracks.video);
    for (let i = 0; i < 40 && !haveInits(); i++) await sleep(150);

    let frontier = start, stall = 0, unsticking = false;
    let firstV = null, firstA = null;
    const note = () => {
      const a = bufferedStartOf('video', start), b = bufferedStartOf('audio', start);
      if (a != null) firstV = firstV == null ? a : Math.min(firstV, a);
      if (b != null) firstA = firstA == null ? b : Math.min(firstA, b);
    };
    const span = Math.max(0.1, end - start);
    const t0 = Date.now();

    try {
      note();
      while (true) {
        await sleep(300);
        if (S.cancel) throw new Error('İptal edildi.');
        if (vidId() !== id) throw new Error('Yakalama sırasında başka videoya geçildi.');
        if (isAd()) throw new Error('Yakalama sırasında reklam başladı. Tekrar dene.');
        note();

        // Oynatıcı duraklıyken tamponu doldurup durur; tamponun sonuna sıçrayıp sonrakini çektiriyoruz.
        const edge = coveredTo(kinds, frontier);
        if (edge != null && edge > frontier + 0.25) {
          frontier = edge;
          stall = 0;
          if (unsticking) { unsticking = false; try { v.pause(); } catch (e) {} }
          seekVia(Math.min(frontier, end - 0.05));
        } else {
          stall++;
          if (!unsticking && stall % 5 === 0) seekVia(Math.min(frontier, end - 0.05));
          if (!unsticking && stall >= 12) { unsticking = true; try { await v.play(); } catch (e) {} }
        }
        if (v.currentTime >= end - 0.4) { unsticking = false; try { v.pause(); } catch (e) {} }
        if (!unsticking) { try { if (!v.paused) v.pause(); } catch (e) {} }

        onProgress(Math.min(0.99, Math.max(0, frontier - start) / span));

        if (frontier >= end - 0.4) break;
        if (frontier >= dur - 1.5) break;
        if (stall >= 25 && frontier >= dur - 3) break;
        if (stall >= 200) break;                           // ~60 sn boyunca yeni veri yok
        if (Date.now() - t0 > 40 * 60 * 1000) break;
      }
      note();
    } finally {
      S.capturing = false;
      try { v.muted = prev.muted; } catch (e) {}
      if (prev.q) setQuality(prev.q);
      seekVia(prev.time);
      if (!prev.paused) { try { v.play(); } catch (e) {} }
    }

    if (!(frontier >= end - 0.5 || frontier >= dur - 3)) {
      throw new Error('Aralığın tamamı yüklenemedi (' + Math.round(frontier) + ' / ' + Math.round(end) + ' sn). Tekrar dene.');
    }
    onProgress(1);
    return { startVideo: firstV == null ? start : firstV, startAudio: firstA == null ? start : firstA, start, end };
  }

  // ---- UI ile haberleşme ----------------------------------------------------
  window.addEventListener('message', async (e) => {
    const m = e.data;
    if (e.source !== window || !m || m.ns !== NS || m.dir !== 'req') return;
    const reply = (obj, tr) => window.postMessage(Object.assign({ ns: NS, dir: 'res', id: m.id }, obj), '*', tr || []);

    if (m.t === 'info') {
      const v = video();
      let title = '';
      try { title = player().getVideoData().title || ''; } catch (err) {}
      if (!title) title = document.title.replace(/\s*-\s*YouTube\s*$/i, '');
      if (!title || /^youtube$/i.test(title.trim())) title = isShorts() ? 'Shorts ' + (vidId() || '') : title;
      reply({ t: 'info', videoId: vidId(), title, duration: v && isFinite(v.duration) ? v.duration : 0, heights: availableHeights(), ad: isAd() });
      return;
    }

    if (m.t === 'cancel') { S.cancel = true; return; }

    if (m.t === 'capture') {
      if (S.busy) { reply({ t: 'error', message: 'Zaten bir indirme sürüyor.' }); return; }
      S.busy = true;
      try {
        const o = m.opts || {};
        const meta = await capture(o, (value) => reply({ t: 'progress', value }));
        const out = { t: 'done', meta, tracks: {} };
        const tr = [];
        for (const k of ['video', 'audio']) {
          const a = assemble(k);
          if (!a) continue;
          if (a.broken) throw new Error('Yakalama sırasında kalite değişti. Tekrar dene.');
          out.tracks[k] = { buf: a.bytes.buffer, mime: a.mime };
          tr.push(a.bytes.buffer);
        }
        if (!out.tracks.audio || (o.needVideo !== false && !out.tracks.video)) {
          throw new Error('Oynatıcıdan veri yakalanamadı. Sayfayı yenileyip tekrar dene.');
        }
        S.tracks = Object.create(null);
        reply(out, tr);
      } catch (err) {
        S.capturing = false;
        reply({ t: 'error', message: String((err && err.message) || err) });
      } finally {
        S.busy = false;
      }
    }
  });
})();
