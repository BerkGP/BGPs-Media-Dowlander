// background.js — servis çalışanı.
// Görevleri: offscreen belgesini yaşatmak, bitmiş dosyayı indirmek,
// ffmpeg ilerlemesini açık sekmeye iletmek. ffmpeg burada çalışamaz (DOM/Worker yok).

let creating = null;
let activeTab = null;

function safeName(name) {
  const dot = name.lastIndexOf('.');
  const ext = dot > 0 ? name.slice(dot) : '';
  const base = (dot > 0 ? name.slice(0, dot) : name)
    .replace(/[\u{1F000}-\u{1FAFF}\u{2190}-\u{2BFF}\u{FE00}-\u{FE0F}\u{200B}-\u{200F}]/gu, '')
    .replace(/[\\/:*?"<>|\u0000-\u001F\u007F]+/g, ' ')
    .replace(/\s+/g, ' ')
    .replace(/^[.\s]+|[.\s]+$/g, '')
    .slice(0, 80)
    .trim();
  return (base || 'video') + ext;
}

async function ensureOffscreen() {
  if (await chrome.offscreen.hasDocument()) return;
  if (creating) { await creating; return; }
  creating = chrome.offscreen.createDocument({
    url: 'offscreen.html',
    reasons: ['WORKERS', 'BLOBS'],
    justification: 'ffmpeg.wasm ile video ve ses parçalarını birleştirmek için.'
  });
  try { await creating; } finally { creating = null; }
}

chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (!msg || typeof msg.t !== 'string') return;

  if (msg.t === 'ytdl-ensure') {
    if (sender.tab) activeTab = sender.tab.id;
    ensureOffscreen()
      .then(() => sendResponse({ ok: true }))
      .catch((e) => sendResponse({ ok: false, error: String(e) }));
    return true;
  }

  if (msg.t === 'ytdl-progress') {
    if (activeTab != null) {
      chrome.tabs.sendMessage(activeTab, { t: 'ytdl-progress', value: msg.value }).catch(() => {});
    }
    return;
  }

  if (msg.t === 'ytdl-save') {
    const save = (filename) => chrome.downloads.download({ url: msg.url, filename, saveAs: false });
    save(msg.filename)
      .then((id) => sendResponse({ ok: true, id, filename: msg.filename }))
      .catch(() => {
        const alt = safeName(msg.filename || 'video');
        save(alt)
          .then((id) => sendResponse({ ok: true, id, filename: alt }))
          .catch((e) => sendResponse({ ok: false, error: String((e && e.message) || e) }));
      });
    return true;
  }
});
