// content_ui.js — ISOLATED world. Oynatıcıya buton + menü ekler, indirmeyi yönetir:
// hook'tan ham parçaları alır -> offscreen'e (ffmpeg) parça parça yollar -> dosya iner.
(function () {
  'use strict';
  if (window.__ytdlUi) return;
  window.__ytdlUi = true;

  const NS = 'ytdl';
  const SVGNS = 'http://www.w3.org/2000/svg';
  const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

  // ---------- küçük yardımcılar ----------
  function el(tag, cls, text) {
    const e = document.createElement(tag);
    if (cls) e.className = cls;
    if (text != null) e.textContent = text;
    return e;
  }
  function parseTime(s) {
    s = String(s || '').trim();
    if (!s) return NaN;
    const p = s.split(':').map(Number);
    if (p.some((x) => !isFinite(x) || x < 0)) return NaN;
    let t = 0;
    for (const x of p) t = t * 60 + x;
    return t;
  }
  function fmt(sec) {
    sec = Math.max(0, Math.round(sec || 0));
    const h = Math.floor(sec / 3600), m = Math.floor((sec % 3600) / 60), s = sec % 60;
    return h + ':' + String(m).padStart(2, '0') + ':' + String(s).padStart(2, '0');
  }
  function safeTitle(s) {
    const t = String(s || '')
      .replace(/[\u{1F000}-\u{1FAFF}\u{2190}-\u{2BFF}\u{FE00}-\u{FE0F}\u{200B}-\u{200F}]/gu, '')
      .replace(/[\\/:*?"<>|\u0000-\u001F\u007F]+/g, ' ')
      .replace(/\s+/g, ' ')
      .replace(/^[.\s]+|[.\s]+$/g, '')
      .slice(0, 100)
      .trim();
    return t || 'video';
  }
  const QLEVEL = { 1080: 'hd1080', 720: 'hd720', 480: 'large', 360: 'medium' };

  // ---------- hook ile haberleşme ----------
  let reqId = 0;
  const pending = new Map();
  window.addEventListener('message', (e) => {
    const m = e.data;
    if (e.source !== window || !m || m.ns !== NS || m.dir !== 'res') return;
    const h = pending.get(m.id);
    if (h) h(m);
  });
  function callHook(t, payload, onProgress, transferDone) {
    return new Promise((resolve, reject) => {
      const id = ++reqId;
      pending.set(id, (m) => {
        if (m.t === 'progress') { if (onProgress) onProgress(m.value); return; }
        pending.delete(id);
        if (m.t === 'error') reject(new Error(m.message));
        else resolve(m);
      });
      window.postMessage(Object.assign({ ns: NS, dir: 'req', id, t }, payload || {}), '*');
      if (t === 'info') setTimeout(() => { if (pending.delete(id)) reject(new Error('Oynatıcı yanıt vermedi. Sayfayı yenile.')); }, 4000);
    });
  }

  // ---------- eklenti (background/offscreen) ile haberleşme ----------
  async function ext(msg) {
    try { return await chrome.runtime.sendMessage(msg); }
    catch (e) {
      const m = String((e && e.message) || e);
      if (/context invalidated/i.test(m)) throw new Error('Eklenti güncellendi. Sayfayı yenile (F5).');
      throw new Error(m);
    }
  }
  async function readyOffscreen() {
    const r = await ext({ t: 'ytdl-ensure' });
    if (!r || !r.ok) throw new Error('Dönüştürücü başlatılamadı: ' + ((r && r.error) || ''));
    for (let i = 0; i < 50; i++) {
      try { const p = await ext({ t: 'ytdl-ping' }); if (p && p.ok) return; } catch (e) {}
      await sleep(200);
    }
    throw new Error('Dönüştürücü yanıt vermedi.');
  }
  const toB64 = (u8) => new Promise((res, rej) => {
    const fr = new FileReader();
    fr.onload = () => res(String(fr.result).split(',')[1]);
    fr.onerror = () => rej(fr.error);
    fr.readAsDataURL(new Blob([u8]));
  });
  async function sendTrack(kind, buf, onStep) {
    const u8 = new Uint8Array(buf);
    const CH = 6 * 1024 * 1024;
    let seq = 0;
    for (let pos = 0; pos < u8.length; pos += CH) {
      const b64 = await toB64(u8.subarray(pos, pos + CH));
      let ok = false, err = '';
      for (let a = 0; a < 3 && !ok; a++) {
        try {
          const r = await ext({ t: 'ytdl-chunk', track: kind, seq, b64 });
          if (r && r.ok) ok = true; else err = (r && r.error) || 'yanıt yok';
        } catch (e) { err = String(e.message || e); }
      }
      if (!ok) throw new Error('Veri aktarılamadı: ' + err);
      seq++;
      onStep(Math.min(u8.length, pos + CH));
    }
  }

  // ---------- toast ----------
  let toastEl = null, toastTxt = null, toastBar = null, toastCancel = null, toastTimer = null;
  function host() { return document.getElementById('movie_player') || document.body; }
  const onShorts = () => /^\/shorts\//.test(location.pathname);
  function ensureToast() {
    if (!toastEl || !toastEl.isConnected) {
      toastEl = el('div', 'ytdl-toast');
      toastTxt = el('span', 'ytdl-toast-txt');
      const bar = el('div', 'ytdl-bar');
      toastBar = el('i');
      bar.appendChild(toastBar);
      toastCancel = el('button', 'ytdl-cancel', 'İptal');
      toastCancel.addEventListener('click', (e) => { e.stopPropagation(); callHook('cancel').catch(() => {}); });
      toastEl.append(toastTxt, bar, toastCancel);
      ['click', 'dblclick', 'mousedown'].forEach((ev) => toastEl.addEventListener(ev, (e) => e.stopPropagation()));
    }
    const sh = onShorts();
    const target = sh ? document.body : host();
    toastEl.classList.toggle('ytdl-fixed', sh);
    if (toastEl.parentElement !== target) target.appendChild(toastEl);
  }
  function toast(text, opts) {
    opts = opts || {};
    ensureToast();
    clearTimeout(toastTimer);
    toastTxt.textContent = text;
    toastBar.parentElement.style.display = opts.progress != null ? '' : 'none';
    if (opts.progress != null) toastBar.style.width = Math.round(Math.max(0, Math.min(1, opts.progress)) * 100) + '%';
    toastCancel.style.display = opts.cancel ? '' : 'none';
    toastEl.classList.add('show');
    if (opts.ms) toastTimer = setTimeout(() => toastEl.classList.remove('show'), opts.ms);
  }

  // ffmpeg ilerlemesi background üzerinden gelir
  let mergeLabel = null;
  chrome.runtime.onMessage.addListener((msg) => {
    if (msg && msg.t === 'ytdl-progress' && mergeLabel) toast(mergeLabel, { progress: msg.value });
  });

  // ---------- indirme akışı ----------
  let busy = false;
  async function getMode() {
    try { const r = await chrome.storage.local.get('mode'); return r.mode === 'h264' ? 'h264' : 'fast'; }
    catch (e) { return 'fast'; }
  }

  async function run(kind, height, startStr, endStr) {
    if (busy) { toast('Zaten bir indirme sürüyor.', { ms: 3000 }); return; }
    busy = true;
    mergeLabel = null;
    try {
      const info = await callHook('info');
      if (!info.duration) throw new Error('Video süresi okunamadı (canlı yayınlar desteklenmez).');
      if (info.ad) throw new Error('Şu an reklam oynuyor. Reklam bitince tekrar dene.');
      const dur = info.duration;

      let start = parseTime(startStr), end = parseTime(endStr);
      if (!isFinite(start)) start = 0;
      if (!isFinite(end) || end <= 0 || end > dur) end = dur;
      if (end - start < 1) throw new Error('Bitiş, başlangıçtan en az 1 saniye sonra olmalı.');
      const fragment = start > 0.5 || end < dur - 0.5;
      const mode = await getMode();
      const mp3 = kind === 'mp3';

      await readyOffscreen();
      ext({ t: 'ytdl-warm' }).catch(() => {});   // ffmpeg yakalama sürerken ısınsın

      toast('Yakalanıyor… Videoyu kapatma, başka videoya geçme.\n(Oynatıcı ileri sarılacak, bu normal.)', { progress: 0, cancel: true });
      const done = await callHook('capture', {
        opts: { start, end, quality: mp3 ? 'tiny' : QLEVEL[height], needVideo: !mp3 }
      }, (p) => toast('Yakalanıyor… %' + Math.round(p * 100) + '\nVideoyu kapatma, başka videoya geçme.', { progress: p, cancel: true }));

      toast('Dönüştürücüye aktarılıyor…', { progress: 0 });
      await readyOffscreen();

      const tr = done.tracks;
      const outLen = end - start;
      const transcode = !mp3 && (fragment || mode === 'h264');
      const title = safeTitle(info.title);
      const filename = mp3 ? title + '.mp3'
        : title + ' [' + height + 'p]' + (fragment ? ' (kesit)' : '') + '.mp4';

      const b = await ext({
        t: 'ytdl-begin',
        format: mp3 ? 'mp3' : 'mp4',
        filename,
        videoMime: tr.video ? tr.video.mime : '',
        audioMime: tr.audio.mime,
        transcode,
        videoSeek: fragment ? Math.max(0, start - done.meta.startVideo) : 0,
        audioSeek: fragment ? Math.max(0, start - done.meta.startAudio) : 0,
        outDuration: fragment ? outLen : 0
      });
      if (!b || !b.ok) throw new Error('Dönüştürücü hazır değil. Tekrar dene.');

      const total = (tr.video ? tr.video.buf.byteLength : 0) + tr.audio.buf.byteLength;
      let sent = 0;
      for (const k of ['video', 'audio']) {
        if (!tr[k]) continue;
        const base = sent;
        await sendTrack(k, tr[k].buf, (n) => toast('Dönüştürücüye aktarılıyor…', { progress: (base + n) / total }));
        sent += tr[k].buf.byteLength;
      }

      mergeLabel = mp3 ? 'MP3 hazırlanıyor…' : (transcode ? 'MP4 dönüştürülüyor (H.264)… bu biraz sürebilir' : 'MP4 birleştiriliyor…');
      toast(mergeLabel, { progress: 0 });
      const r = await ext({ t: 'ytdl-finalize' });
      mergeLabel = null;
      if (!r || !r.ok) throw new Error((r && r.error) || 'Dönüştürme başarısız.');
      toast('✅ İndirildi: ' + r.filename, { ms: 8000 });
    } catch (e) {
      mergeLabel = null;
      toast('❌ ' + ((e && e.message) || e), { ms: 10000 });
    } finally {
      busy = false;
    }
  }

  // ---------- menü ----------
  let menuEl = null, btnEl = null, sBtn = null, lastKey = '';
  function stopBubble(node) {
    ['click', 'dblclick', 'mousedown', 'mouseup', 'contextmenu', 'wheel'].forEach((ev) => node.addEventListener(ev, (e) => e.stopPropagation()));
  }
  function ensureMenu() {
    if (!menuEl) {
      menuEl = el('div', 'ytdl-menu');
      stopBubble(menuEl);
      document.addEventListener('click', (e) => {
        if (!menuEl) return;
        const t = e.target;
        if (menuEl.contains(t) || (t && t.closest && t.closest('.ytdl-btn, .ytdl-sbtn, .ytdl-act'))) return;
        menuEl.classList.remove('open');
      });
    }
    return menuEl;
  }
  function setMenuMode(fixed) {
    menuEl.classList.toggle('ytdl-fixed', fixed);
    if (!fixed) { menuEl.style.left = menuEl.style.top = menuEl.style.bottom = menuEl.style.maxHeight = ''; }
  }

  const ICON_DL = 'M11 4h2v8.2l3.1-3.1 1.4 1.4L12 16l-5.5-5.5 1.4-1.4L11 12.2V4zM5 18h14v2H5z';
  const ICON_NOTE = 'M12 3v10.55A4 4 0 1 0 14 17V7h4V3h-6z';
  function svgIcon(d) {
    const svg = document.createElementNS(SVGNS, 'svg');
    svg.setAttribute('viewBox', '0 0 24 24');
    const path = document.createElementNS(SVGNS, 'path');
    path.setAttribute('d', d);
    svg.appendChild(path);
    return svg;
  }
  const QNAME = { 1080: 'Full HD', 720: 'HD', 480: 'Standart', 360: 'Düşük' };

  async function renderMenu() {
    menuEl.textContent = '';

    // başlık
    const head = el('div', 'ytdl-head');
    const logo = el('div', 'ytdl-logo'); logo.appendChild(svgIcon(ICON_DL));
    const close = el('button', 'ytdl-close', '×');
    close.title = 'Kapat';
    close.addEventListener('click', () => menuEl.classList.remove('open'));
    let ver = '';
    try { ver = 'v' + chrome.runtime.getManifest().version; } catch (e) {}
    const title = el('div', 'ytdl-title', "BGP's Medya İndirici");
    if (ver) title.appendChild(el('span', 'ytdl-ver', ver));
    head.append(logo, title, close);
    menuEl.appendChild(head);

    const loading = el('div', 'ytdl-note', 'Yükleniyor…');
    menuEl.appendChild(loading);

    let info;
    try { info = await callHook('info'); }
    catch (e) { loading.textContent = '❌ ' + e.message; return; }
    loading.remove();
    if (!info.duration) { menuEl.appendChild(el('div', 'ytdl-note', 'Video süresi okunamadı (canlı yayınlar desteklenmez).')); return; }

    // süre aralığı
    const secRange = el('div', 'ytdl-sec');
    secRange.appendChild(el('span', null, 'Süre aralığı'));
    const reset = el('button', 'ytdl-reset', 'Tüm video');
    secRange.appendChild(reset);
    menuEl.appendChild(secRange);

    const frag = el('div', 'ytdl-frag');
    const inS = el('input', 'ytdl-time'); inS.value = fmt(0);
    const inE = el('input', 'ytdl-time'); inE.value = fmt(info.duration);
    [inS, inE].forEach((i) => ['keydown', 'keyup', 'keypress'].forEach((ev) => i.addEventListener(ev, (e) => e.stopPropagation())));
    reset.addEventListener('click', () => { inS.value = fmt(0); inE.value = fmt(info.duration); });
    const f1 = el('div', 'ytdl-field'); f1.append(el('span', 'ytdl-lbl', 'Başlangıç'), inS);
    const f2 = el('div', 'ytdl-field'); f2.append(el('span', 'ytdl-lbl', 'Bitiş'), inE);
    frag.append(f1, el('span', 'ytdl-dash', '–'), f2);
    menuEl.appendChild(frag);

    const start = (kind, h) => { menuEl.classList.remove('open'); run(kind, h, inS.value, inE.value); };

    // video
    menuEl.appendChild(el('div', 'ytdl-sec', 'Video (MP4)'));
    const avail = info.heights && info.heights.length ? info.heights : [1080, 720, 480, 360];
    let list = [1080, 720, 480, 360].filter((h) => avail.indexOf(h) !== -1);
    if (!list.length) list = [720, 360];
    const grid = el('div', 'ytdl-grid');
    list.forEach((h) => {
      const it = el('div', 'ytdl-chip');
      it.append(el('b', null, h + 'p'), el('span', null, QNAME[h] || 'mp4'));
      it.addEventListener('click', () => start('mp4', h));
      grid.appendChild(it);
    });
    menuEl.appendChild(grid);

    // ses
    menuEl.appendChild(el('div', 'ytdl-sec', 'Ses'));
    const mp3 = el('div', 'ytdl-item');
    const ico = el('div', 'ytdl-ico'); ico.appendChild(svgIcon(ICON_NOTE));
    const mt = el('div', 'ytdl-it'); mt.append(el('b', null, 'MP3'), el('span', null, 'Sadece ses'));
    mp3.append(ico, mt);
    mp3.addEventListener('click', () => start('mp3', 0));
    menuEl.appendChild(mp3);

    // video biçimi
    menuEl.appendChild(el('div', 'ytdl-sec', 'Video biçimi'));
    const mode = await getMode();
    const opts = [
      { key: 'fast', t: 'Hızlı', d: 'Yeniden kodlama yok (H.264 + AAC), saniyeler sürer.' },
      { key: 'h264', t: 'H.264 (uyumlu)', d: 'Eski oynatıcılar için, daha yavaş.' }
    ];
    const seg = el('div', 'ytdl-seg');
    const desc = el('div', 'ytdl-note');
    const btns = [];
    const setDesc = (key) => { desc.textContent = opts.find((o) => o.key === key).d + ' Kısmi aralık seçersen kesit H.264 olarak kodlanır.'; };
    opts.forEach((o) => {
      const b = el('button', 'ytdl-segbtn' + (o.key === mode ? ' sel' : ''), o.t);
      b.addEventListener('click', () => {
        btns.forEach((x) => x.classList.remove('sel'));
        b.classList.add('sel');
        setDesc(o.key);
        try { chrome.storage.local.set({ mode: o.key }); } catch (e) {}
      });
      btns.push(b);
      seg.appendChild(b);
    });
    setDesc(mode);
    menuEl.append(seg, desc);
    menuEl.appendChild(el('div', 'ytdl-credit', 'made by @berkgp'));
  }

  function makeIcon() { return svgIcon(ICON_DL); }

  function inject() {
    if (!/^\/watch/.test(location.pathname)) return;
    const bar = document.querySelector('.ytp-right-controls');
    const pl = document.getElementById('movie_player');
    if (!bar || !pl) return;

    ensureMenu();
    setMenuMode(false);
    if (menuEl.parentElement !== pl) pl.appendChild(menuEl);

    if (bar.querySelector('.ytdl-btn')) return;
    btnEl = el('button', 'ytp-button ytdl-btn');
    btnEl.title = "BGP's Medya İndirici";
    btnEl.appendChild(makeIcon());
    btnEl.addEventListener('click', (e) => {
      e.stopPropagation();
      const open = !menuEl.classList.contains('open');
      menuEl.classList.toggle('open', open);
      if (open) renderMenu();
    });
    bar.insertBefore(btnEl, bar.firstChild);
  }

  // İkonun dikey ortasını oynatıcıdaki ayar (dişli) ikonuyla aynı hizaya getirir.
  function alignBtn() {
    if (!btnEl || !btnEl.isConnected) return;
    const ref = document.querySelector('#movie_player .ytp-settings-button') ||
                document.querySelector('#movie_player .ytp-right-controls .ytp-button:not(.ytdl-btn)');
    const mine = btnEl.querySelector('svg');
    if (!ref || !mine) return;
    const a = (ref.querySelector('svg') || ref).getBoundingClientRect();
    const b = mine.getBoundingClientRect();
    if (!a.height || !b.height) return;
    const dy = (a.top + a.height / 2) - (b.top + b.height / 2);
    if (Math.abs(dy) < 0.5) return;
    const cur = parseFloat(btnEl.style.getPropertyValue('--ytdl-dy')) || 0;
    btnEl.style.setProperty('--ytdl-dy', (cur + dy).toFixed(1) + 'px');
  }

  // ---------- Shorts ----------
  // Ana yol: beğeni/yorum/paylaş/remix sütununa, Remix'in hemen altına (kanal avatarının üstüne),
  // YouTube'un kendi düğmeleri gibi görünen bir düğme.
  // Sütun bulunamazsa yedek: ekranın sağ altında SABİT duran yuvarlak düğme (videoyu takip etmez, kaymaz).
  let aBtn = null;
  const MENU_W = 300;

  const activeReel = () => document.querySelector('ytd-reel-video-renderer[is-active]');

  function shortsRect() {
    const cands = [
      document.querySelector('ytd-reel-video-renderer[is-active] #shorts-player'),
      document.getElementById('shorts-player'),
      document.querySelector('ytd-reel-video-renderer[is-active] video'),
      activeReel(),
      document.querySelector('video')
    ];
    for (const c of cands) {
      if (!c) continue;
      const r = c.getBoundingClientRect();
      if (r.width > 60 && r.height > 60) return r;
    }
    return null;
  }

  // Düğmelerin dizildiği sütunu bulur (birkaç yöntem, en kesin olandan başlar).
  function findColumn() {
    const act = activeReel();
    if (!act) return null;
    // 1) beğen düğmesinin bulunduğu liste
    const like = act.querySelector('like-button-view-model');
    if (like) {
      let node = like;
      for (let i = 0; i < 3; i++) {
        const p = node.parentElement;
        if (!p || p === act) break;
        if (p.children.length >= 3) return p;
        node = p;
      }
    }
    // 2) eylem çubuğu / eski #actions
    let c = act.querySelector('reel-action-bar-view-model') ||
            act.querySelector('ytd-reel-player-overlay-renderer #actions') ||
            act.querySelector('#actions');
    if (c) {
      for (let i = 0; i < 3 && c.children.length === 1; i++) c = c.children[0];
      return c;
    }
    return null;
  }

  function toggleShortsMenu() {
    const open = !menuEl.classList.contains('open');
    menuEl.classList.toggle('open', open);
    if (open) { renderMenu(); placeShorts(); }
  }
  function makeActionBtn() {
    const wrap = el('div', 'ytdl-act');
    const b = el('button', 'ytdl-act-btn');
    b.title = "BGP's Medya İndirici";
    b.appendChild(makeIcon());
    wrap.append(b, el('span', 'ytdl-act-lbl', 'İndir'));
    ['mousedown', 'mouseup', 'dblclick', 'contextmenu'].forEach((ev) => wrap.addEventListener(ev, (e) => e.stopPropagation()));
    b.addEventListener('click', (e) => { e.stopPropagation(); toggleShortsMenu(); });
    return wrap;
  }

  // Düğmeyi sütunda Remix'in altına yerleştirir: son öğe kanal avatarıysa onun önüne, değilse en sona.
  function putInColumn(col) {
    const kids = Array.from(col.children).filter((k) => k !== aBtn);
    const last = kids[kids.length - 1];
    const hasAvatar = !!(last && last.querySelector && last.querySelector('img, yt-img-shape, yt-avatar-shape'));
    const want = hasAvatar ? last : null;
    if (aBtn.parentElement === col && aBtn.nextElementSibling === want) return;
    const ref = hasAvatar ? kids[kids.length - 2] : last;
    if (ref) {
      try {
        const cs = getComputedStyle(ref);
        aBtn.style.marginTop = cs.marginTop;
        aBtn.style.marginBottom = cs.marginBottom;
      } catch (e) {}
    }
    col.insertBefore(aBtn, want);
  }

  function injectShorts() {
    ensureMenu();
    setMenuMode(true);
    if (menuEl.parentElement !== document.body) document.body.appendChild(menuEl);

    const col = findColumn();
    if (col) {
      if (!aBtn) aBtn = makeActionBtn();
      putInColumn(col);
      if (sBtn) sBtn.style.display = 'none';
    } else {
      if (aBtn && aBtn.isConnected) aBtn.remove();
      if (!sBtn || !sBtn.isConnected) {
        sBtn = el('button', 'ytdl-sbtn');
        sBtn.title = "BGP's Medya İndirici";
        sBtn.appendChild(makeIcon());
        ['mousedown', 'mouseup', 'dblclick', 'contextmenu'].forEach((ev) => sBtn.addEventListener(ev, (e) => e.stopPropagation()));
        sBtn.addEventListener('click', (e) => { e.stopPropagation(); toggleShortsMenu(); });
        document.body.appendChild(sBtn);
      }
    }
    placeShorts();
  }

  function placeShorts() {
    if (!menuEl) return;
    const useAct = !!(aBtn && aBtn.isConnected);
    let anchor = aBtn;
    if (!useAct) {
      if (!sBtn) return;
      if (!shortsRect()) { sBtn.style.display = 'none'; menuEl.classList.remove('open'); return; }
      sBtn.style.display = 'grid';
      anchor = sBtn;
    }
    const ar = anchor.getBoundingClientRect();
    if (!ar.width) { menuEl.classList.remove('open'); return; }
    if (!menuEl.classList.contains('open')) return;
    // menü, düğmenin soluna açılır; alt kenarı düğmeyle hizalı
    let left = ar.left - MENU_W - 12;
    if (left < 8) left = Math.max(8, Math.min(ar.left, window.innerWidth - MENU_W - 8));
    const bottom = Math.max(8, window.innerHeight - Math.min(ar.bottom, window.innerHeight));
    menuEl.style.left = left + 'px';
    menuEl.style.top = 'auto';
    menuEl.style.bottom = bottom + 'px';
    menuEl.style.maxHeight = Math.max(160, window.innerHeight - bottom - 12) + 'px';
  }
  function hideShorts() {
    if (sBtn) sBtn.style.display = 'none';
    if (aBtn && aBtn.isConnected) aBtn.remove();
  }

  function tick() {
    // video değişince açık menü kapansın
    const key = location.pathname + location.search;
    if (key !== lastKey) { lastKey = key; if (menuEl) menuEl.classList.remove('open'); }
    if (onShorts()) injectShorts();
    else { hideShorts(); inject(); }
    alignBtn();
  }

  setInterval(tick, 1000);
  // Shorts'ta video kaydırılınca düğme yeni videonun sütununa hemen taşınsın
  setInterval(() => { if (onShorts()) injectShorts(); }, 250);
})();
