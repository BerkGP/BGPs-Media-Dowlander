// offscreen.js — ffmpeg.wasm'ı çalıştırır. Yakalanan ham video/ses parçalarını
// parça parça alır, MP4 / MP3 dosyasına dönüştürür, kaydetmesi için background'a verir.

const { FFmpeg } = FFmpegWASM;

let ff = null;
let loading = null;
const ffLog = [];
const job = {};

function resetJob() {
  Object.assign(job, {
    video: [], audio: [], n: { video: 0, audio: 0 },
    videoMime: '', audioMime: '', filename: 'video.mp4', format: 'mp4',
    transcode: false, videoSeek: 0, audioSeek: 0, outDuration: 0
  });
}
resetJob();

async function getFF() {
  if (ff) return ff;
  if (loading) return loading;
  loading = (async () => {
    const inst = new FFmpeg();
    inst.on('progress', ({ progress }) => {
      const v = Math.max(0, Math.min(1, Number(progress) || 0));
      try { chrome.runtime.sendMessage({ t: 'ytdl-progress', value: v }); } catch (e) {}
    });
    inst.on('log', ({ message }) => {
      ffLog.push(message);
      if (ffLog.length > 40) ffLog.shift();
    });
    const base = chrome.runtime.getURL('vendor/ffmpeg/');
    await inst.load({ coreURL: base + 'ffmpeg-core.js', wasmURL: base + 'ffmpeg-core.wasm' });
    ff = inst;
    return inst;
  })();
  try { return await loading; } finally { loading = null; }
}

function dropFF() {
  try { if (ff) ff.terminate(); } catch (e) {}
  ff = null;
}

function b64decode(s) {
  const bin = atob(s);
  const u8 = new Uint8Array(bin.length);
  for (let i = 0; i < bin.length; i++) u8[i] = bin.charCodeAt(i);
  return u8;
}

function concat(parts) {
  let n = 0;
  for (const p of parts) n += p.length;
  const out = new Uint8Array(n);
  let o = 0;
  for (const p of parts) { out.set(p, o); o += p.length; }
  return out;
}

const extFor = (mime) => (/webm/i.test(mime) ? 'webm' : /mp4/i.test(mime) ? 'mp4' : 'bin');

async function finalize() {
  const inst = await getFF();
  const mp3 = job.format === 'mp3';

  const aName = 'a.' + extFor(job.audioMime);
  const aBytes = concat(job.audio);
  if (!aBytes.length) throw new Error('Ses verisi boş.');
  await inst.writeFile(aName, aBytes);

  let vName = null;
  if (!mp3) {
    vName = 'v.' + extFor(job.videoMime);
    const vBytes = concat(job.video);
    if (!vBytes.length) throw new Error('Video verisi boş.');
    await inst.writeFile(vName, vBytes);
  }
  job.video = []; job.audio = [];

  // Kesit istenirse her parçanın kendi başlangıcına göre ayrı ayrı kırpılır:
  // ses parçası genelde videodan birkaç saniye önce başlar, aksi halde kayar.
  const ss = (x) => (x > 0.02 ? ['-ss', x.toFixed(3)] : []);
  const limit = job.outDuration > 0.05 ? ['-t', job.outDuration.toFixed(3)] : [];
  const vIn = () => [...ss(job.videoSeek), '-i', vName];
  const aIn = () => [...ss(job.audioSeek), '-i', aName];
  const maps = ['-map', '0:v:0', '-map', '1:a:0'];

  const h264 = {
    name: 'h264', out: 'out.mp4', type: 'video/mp4', ext: '.mp4',
    args: [...vIn(), ...aIn(), ...maps, ...limit,
      '-c:v', 'libx264', '-preset', job.outDuration > 0 && job.outDuration <= 120 ? 'ultrafast' : 'veryfast',
      '-crf', '20', '-pix_fmt', 'yuv420p', '-c:a', 'aac', '-b:a', '160k',
      '-movflags', '+faststart', 'out.mp4']
  };

  const runs = [];
  if (mp3) {
    runs.push({
      name: 'mp3', out: 'out.mp3', type: 'audio/mpeg', ext: '.mp3',
      args: [...aIn(), ...limit, '-vn', '-c:a', 'libmp3lame', '-b:a', '192k', 'out.mp3']
    });
  } else if (job.transcode) {
    runs.push(h264);
  } else {
    runs.push({
      name: 'mp4-copy', out: 'out.mp4', type: 'video/mp4', ext: '.mp4',
      // Video kopyalanır; ses Opus/WebM ise MP4 içinde Windows Filmler ve TV gibi
      // oynatıcılarda çalmaz, bu yüzden sadece ses AAC'ye çevrilir (hızlıdır).
      args: ['-i', vName, '-i', aName, ...maps, '-c:v', 'copy',
        ...(/mp4/i.test(job.audioMime) ? ['-c:a', 'copy'] : ['-c:a', 'aac', '-b:a', '192k']),
        '-strict', '-2', '-avoid_negative_ts', 'make_zero', '-movflags', '+faststart', 'out.mp4']
    });
    runs.push({
      name: 'webm-copy', out: 'out.webm', type: 'video/webm', ext: '.webm',
      args: ['-i', vName, '-i', aName, ...maps, '-c', 'copy', '-avoid_negative_ts', 'make_zero', 'out.webm']
    });
    runs.push(h264);
  }

  let data = null, chosen = null;
  const fails = [];
  for (const run of runs) {
    ffLog.length = 0;
    let ret = -1;
    try { ret = await inst.exec(run.args); } catch (e) { ffLog.push(String((e && e.message) || e)); }
    if (ret === 0) {
      try {
        const out = await inst.readFile(run.out);
        if (out && out.length > 1024) { data = out; chosen = run; break; }
        fails.push(run.name + ': boş çıktı');
      } catch (e) { fails.push(run.name + ': dosya oluşmadı'); }
    } else {
      fails.push(run.name + ' (kod ' + ret + '): ' + ffLog.slice(-3).join(' | '));
    }
    try { await inst.deleteFile(run.out); } catch (e) {}
  }

  if (!chosen) { dropFF(); throw new Error(fails.join('  ||  ') || 'ffmpeg dosyayı oluşturamadı'); }

  const filename = job.filename.replace(/\.(mp4|webm|mp3)$/i, '') + chosen.ext;
  const blob = new Blob([data], { type: chosen.type });
  const url = URL.createObjectURL(blob);
  dropFF(); // wasm belleğini geri ver
  const res = await chrome.runtime.sendMessage({ t: 'ytdl-save', url, filename });
  setTimeout(() => { try { URL.revokeObjectURL(url); } catch (e) {} }, 5 * 60 * 1000);
  resetJob();
  return res && res.ok
    ? { ok: true, filename: res.filename || filename }
    : { ok: false, error: (res && res.error) || 'Kaydedilemedi' };
}

chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (!msg || typeof msg.t !== 'string') return;

  if (msg.t === 'ytdl-ping') { sendResponse({ ok: true }); return; }

  if (msg.t === 'ytdl-warm') {
    getFF().then(() => sendResponse({ ok: true })).catch(() => sendResponse({ ok: false }));
    return true;
  }

  if (msg.t === 'ytdl-begin') {
    resetJob();
    job.videoMime = msg.videoMime || '';
    job.audioMime = msg.audioMime || '';
    job.filename = msg.filename || 'video.mp4';
    job.format = msg.format || 'mp4';
    job.transcode = !!msg.transcode;
    job.videoSeek = Math.max(0, Number(msg.videoSeek) || 0);
    job.audioSeek = Math.max(0, Number(msg.audioSeek) || 0);
    job.outDuration = Math.max(0, Number(msg.outDuration) || 0);
    getFF().catch(() => {});
    sendResponse({ ok: true });
    return;
  }

  if (msg.t === 'ytdl-chunk') {
    try {
      const k = msg.track === 'video' ? 'video' : 'audio';
      const seq = Number(msg.seq);
      // Numaralı parça: yanıtı kaybolan bir parça tekrar gelirse veriyi ikiye katlamasın.
      if (seq < job.n[k]) { sendResponse({ ok: true, duplicate: true }); return; }
      if (seq > job.n[k]) { sendResponse({ ok: false, error: 'Bir veri parçası atlandı.' }); return; }
      job[k].push(b64decode(msg.b64));
      job.n[k]++;
      sendResponse({ ok: true });
    } catch (e) {
      sendResponse({ ok: false, error: String(e) });
    }
    return;
  }

  if (msg.t === 'ytdl-finalize') {
    finalize()
      .then((r) => sendResponse(r))
      .catch((e) => sendResponse({ ok: false, error: String((e && e.message) || e) }));
    return true;
  }
});
